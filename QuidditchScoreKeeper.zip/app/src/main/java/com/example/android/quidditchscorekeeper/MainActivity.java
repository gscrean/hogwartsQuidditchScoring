package com.example.android.quidditchscorekeeper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.android.quidditchscorekeeper.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    String[] teamNames = {"Which team?", "Gryffindor", "Hufflepuff", "Ravenclaw", "Slytherin"};
    String teamNameA = teamNames[0];
    String teamNameB = teamNames[0];
    int scoreTeamA = 0;
    int scoreTeamB = 0;
    int nameAIndex = 0;
    int nameBIndex = 0;

    // Updates the score display for team A.
    public void displayForTeamA(int score) {
        scoreTeamA = scoreTeamA + score;
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(scoreTeamA));
    }

    // Updates the score display for team B.
    public void displayForTeamB(int score) {
        scoreTeamB = scoreTeamB + score;
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(scoreTeamB));
    }

    // Gives team A 150 points for catching the golden snitch.
    public void goldenSnitchA(View view) {
        displayForTeamA(150);
    }

    // Gives team B 150 points for catching the golden snitch.
    public void goldenSnitchB(View view) {
        displayForTeamB(150);
    }

    // Give team A 10 points for making a regular goal.
    public void goalA(View view) {
        displayForTeamA(10);
    }

    // Give team B 10 points for making a regular goal.
    public void goalB(View view) {
        displayForTeamB(10);
    }

    // Resets score for both reams and ets all displays to their default value.
    public void resetScores(View view) {
        scoreTeamA = 0;
        scoreTeamB = 0;
        teamNameA = teamNames[0];
        teamNameB = teamNames[0];
        nameAIndex = 0;
        nameBIndex = 0;
        displayForTeamA(0);
        displayForTeamB(0);
        refreshNames(teamNameA, teamNameB);
    }

    // Cycles through names for team A, skipping the name selected for Team B, if applicable.
    public void nameTeamA(View view) {
        nameAIndex = cycleNameArray(nameAIndex);
        if (nameAIndex == nameBIndex) {
            nameAIndex = cycleNameArray(nameAIndex);
        }
        teamNameA = teamNames[nameAIndex];
        refreshNames(teamNameA, teamNameB);
    }

    // Cycles through names for team B, skipping the name selected for Team A, if applicable.
    public void nameTeamB(View view) {
        nameBIndex = cycleNameArray(nameBIndex);
        if (nameAIndex == nameBIndex) {
            nameBIndex = cycleNameArray(nameBIndex);
        }
        teamNameB = teamNames[nameBIndex];
        refreshNames(teamNameA, teamNameB);
    }

    // A common method for A and B name cycling, going through array indexes.
    public int cycleNameArray(int teamIndex) {
        if (teamIndex < 4) {
            teamIndex = teamIndex + 1;
        } else {
            teamIndex = 1;
        }
        return teamIndex;
    }

    // Sets the name displays to show the current name of the teams.
    public void refreshNames(String teamAName, String teamBName) {
        TextView nameA = (TextView) findViewById(R.id.team_a_name);
        nameA.setText(String.valueOf(teamAName));
        TextView nameB = (TextView) findViewById(R.id.team_b_name);
        nameB.setText(String.valueOf(teamBName));
    }
}
